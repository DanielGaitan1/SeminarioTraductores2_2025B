#include "semantico.h"

// --- Constructor (Como pide el PDF) ---
Semantico::Semantico(){
    // Inicializa la tabla de s�mbolos y la "conecta"
    // a la variable est�tica de la clase Nodo.
    Nodo::tablaSimbolos = tablaSimbolos = new TablaSimbolos(&listaErrores);
}

// --- M�todo 'analiza' (Como pide el PDF) ---
void Semantico::analiza(Nodo *arbol){
    this->arbol = arbol;

    // 1. Inicia el recorrido del �rbol
    if (arbol) { // Solo si el �rbol no est� vac�o
        arbol->validaTipos();
    }

    // 2. Muestra la tabla de s�mbolos
    cout << endl << "------ TABLA DE SIMBOLOS ------" << endl;
    tablaSimbolos->muestra();

    // 3. Muestra los errores (si los hay)
    cout << endl;
    muestraErrores();
}
